URJADRISHTI M001 REFERENCE TEST INPUTS

Contents
- M001_normal_reference.csv: exact file normal/44.6464.csv from normal.zip. It is headerless, 8 numeric columns, 250000 rows, 50 kHz. Select this same CSV for both Machine Health upload prompts. Audio uses channel 8; vibration uses channels 2-4.
- M001_valve_normal_reference.wav: exact file valve/id_00/normal/00000077.wav from 6_dB_valve.zip. Source label: normal. Use it as a normal-sound reference for the Air Leak screen.
- M001_reference_test_packet.pdf: readable summary. PDF files are not accepted by model upload controls.

Illustrative M001 meter values: current 8.4 kW, baseline 9.2 kW, prototype idle cutoff 3.0 kW. Therefore the sample reading is non-idle under the current simple rule. This meter value is illustrative and not part of the supplied datasets.

Observed current-bundle outputs: machine audio anomaly 5/100, vibration anomaly 1/100, electrical deviation 9/100, fused health 95/100 (Healthy); valve abnormal-sound score 5/100 (below prototype 55/100 threshold). These are experimental outputs, not guarantees for real factory machines.
